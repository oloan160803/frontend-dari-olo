// pages/index.js
import dynamic from 'next/dynamic'
import { useState } from 'react'

// Hooks (moved to top-level hooks/)
import useAALProvinsi from '../hooks/useAALProvinsi'
import useChartData   from '../hooks/useChartData'
import useDirectLoss  from '../hooks/useDirectLoss'

// Components
import Header            from '../components/Header'
import FilterChoropleth  from '../components/FilterChoropleth'
const ChoroplethMap     = dynamic(() => import('../components/ChoroplethMap'), { ssr: false })

import ChartsSection     from '../components/ChartsSection'
import FilterDirectLoss  from '../components/FilterDirectLoss'
const DirectLossMap     = dynamic(() => import('../components/DirectLossMap'), { ssr: false })

import CrudHSBGN         from '../components/CrudHSBGN'
import CrudBuildings     from '../components/CrudBuildings'
import LegendAAL         from '../components/LegendAAL'

export default function Home() {
  // Choropleth state
  const [hazard, setHazard] = useState('')
  const [period, setPeriod] = useState('')
  const [model, setModel]   = useState('')
  const { geojson }         = useAALProvinsi()

  // Charts state
  const { provs, data, load } = useChartData()

  // Direct Loss state
  const direct = useDirectLoss()

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200">
      <Header />
      
      <main className="max-w-screen-2xl mx-auto py-10 px-6 space-y-12">
        {/* Top Section: AAL Choropleth Cards */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Card: Filters, Map & Button */}
          <div className="bg-gray-800 shadow-lg rounded-lg p-6 flex flex-col space-y-4 md:col-span-2">
            <h2 className="text-2xl font-bold text-white mb-2">Average Annual Loss di Indonesia</h2>
            <FilterChoropleth
              hazard={hazard}
              setHazard={setHazard}
              period={period}
              setPeriod={setPeriod}
              model={model}
              setModel={setModel}
            />
            <div className="h-96 bg-gray-700 rounded-lg overflow-hidden">
              <ChoroplethMap
                geojson={geojson}
                hazard={hazard}
                period={period}
                model={model}
              />
            </div>
            <div className="flex justify-end">
              <button
                className="px-6 py-2 bg-blue-700 text-white font-semibold rounded-lg hover:bg-blue-800 transition"
                onClick={() => window.open('/api/aal-provinsi/download', '_blank')}
              >
                Download AAL CSV
              </button>
            </div>
          </div>

          {/* Right Column: AAL & Vulnerability */}
          <div className="flex flex-col space-y-6">
            {/* AAL Value Card */}
            <div className="bg-gray-800 shadow-lg rounded-lg p-6 flex items-center justify-center h-48">
              <h3 className="text-xl font-semibold text-white">Nilai Average Annual Loss (Rupiah)</h3>
            </div>
            {/* Vulnerability Curve Card */}
            <div className="bg-gray-800 shadow-lg rounded-lg p-6 flex flex-col space-y-4 h-96">
              <h4 className="text-lg font-semibold text-white mb-2">Kurva Kerentanan Bencana</h4>
              <ChartsSection provs={provs} data={data} load={load} />
            </div>
          </div>
        </section>

        {/* Direct Loss Analysis Section */}
        <section className="bg-gray-800 shadow-lg rounded-lg p-6">
          <h2 className="text-xl font-semibold text-white mb-4">Direct Loss Analysis</h2>
          <div className="space-y-6">
            <FilterDirectLoss {...direct} />
            <div className="h-80 bg-gray-700 rounded-lg overflow-hidden">
              <DirectLossMap
                geojson={direct.geojson}
                filters={direct.filters}
                search={direct.search}
              />
            </div>
          </div>
        </section>

        {/* Management Cards Section */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* HSBGN Management */}
          <div className="bg-gray-800 shadow-lg rounded-lg p-6">
            <h4 className="text-lg font-semibold text-white mb-4">Manajemen HSBGN</h4>
            <CrudHSBGN />
          </div>

          {/* Building Management */}
          <div className="bg-gray-800 shadow-lg rounded-lg p-6">
            <h4 className="text-lg font-semibold text-white mb-4">Manajemen Bangunan</h4>
            <CrudBuildings />
          </div>
        </section>
      </main>
    </div>
  )
}
