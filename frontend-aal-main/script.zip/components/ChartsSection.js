// components/ChartsSection.js
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js'
import { Bar } from 'react-chartjs-2'

// Register scales & elements
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend)

const hazards = [
  {
    key: 'gempa',
    label: 'Gempa Bumi',
    periods: ['500', '250', '100'],
    colors: ['#2563eb', '#60a5fa', '#a5b4fc']
  },
  {
    key: 'banjir',
    label: 'Banjir',
    periods: ['100', '50', '25'],
    colors: ['#22c55e', '#86efac', '#bbf7d0']
  },
  {
    key: 'longsor',
    label: 'Longsor',
    periods: ['5', '2'],
    colors: ['#f59e42', '#fde68a']
  },
  {
    key: 'gunungberapi',
    label: 'Gunung Berapi',
    periods: ['250', '100', '50'],
    colors: ['#e11d48', '#f472b6', '#fbcfe8']
  }
];

function buildGroupedDatasets(data, tipe) {
  // tipe: 'total', 'bmn', 'fs', 'fd'
  const datasets = [];
  hazards.forEach((hazard, hIdx) => {
    hazard.periods.forEach((period, pIdx) => {
      datasets.push({
        label: `${hazard.label} ${period}`,
        backgroundColor: hazard.colors[pIdx],
        data: hazards.map((hz, idx) => {
          if (hz.key !== hazard.key) return 0;
          return data?.[`aal_${hz.key}_${period}_${tipe}`] ?? 0;
        })
      });
    });
  });
  return datasets;
}

const chartOptions = {
  responsive: true,
  plugins: {
    legend: { display: false },
    title: { display: false }
  },
  scales: {
    y: {
      beginAtZero: true,
      ticks: {
        color: '#e5e7eb',
        callback: value => 'Rp ' + value.toLocaleString('id-ID', { minimumFractionDigits: 0 })
      },
      grid: { color: '#374151' }
    },
    x: {
      stacked: false,
      ticks: {
        font: { size: 14 },
        color: '#e5e7eb'
      },
      grid: { display: false }
    }
  },
  elements: {
    bar: {
      borderRadius: 8,
      borderSkipped: false,
      barPercentage: 1,
      categoryPercentage: 0.1
    }
  }
};

export default function ChartsSection({ provs, data, load }) {
  return (
    <section className="p-0">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Semua Bangunan */}
        <div className="bg-gray-800 border border-gray-700 shadow rounded-lg p-4 flex flex-col items-center">
          <h3 className="text-lg font-bold text-gray-200 mb-2">Semua Bangunan</h3>
          <div className="h-32 w-full bg-gray-700 rounded mb-3 flex items-center justify-center">
            <Bar
              data={{
                labels: hazards.map(h => h.label),
                datasets: buildGroupedDatasets(data, 'total')
              }}
              options={chartOptions}
            />
          </div>
          <span className="text-center text-gray-400">Gempa Bumi • Banjir • Longsor • Gunung Berapi</span>
        </div>
        {/* BMN */}
        <div className="bg-gray-800 border border-gray-700 shadow rounded-lg p-4 flex flex-col items-center">
          <h3 className="text-lg font-bold text-gray-200 mb-2">Bangunan Milik Negara</h3>
          <div className="h-32 w-full bg-gray-700 rounded mb-3 flex items-center justify-center">
            <Bar
              data={{
                labels: hazards.map(h => h.label),
                datasets: buildGroupedDatasets(data, 'bmn')
              }}
              options={chartOptions}
            />
          </div>
          <span className="text-center text-gray-400">Gempa Bumi • Banjir • Longsor • Gunung Berapi</span>
        </div>
        {/* FS */}
        <div className="bg-gray-800 border border-gray-700 shadow rounded-lg p-4 flex flex-col items-center">
          <h3 className="text-lg font-bold text-gray-200 mb-2">Fasilitas Kesehatan</h3>
          <div className="h-32 w-full bg-gray-700 rounded mb-3 flex items-center justify-center">
            <Bar
              data={{
                labels: hazards.map(h => h.label),
                datasets: buildGroupedDatasets(data, 'fs')
              }}
              options={chartOptions}
            />
          </div>
          <span className="text-center text-gray-400">Gempa Bumi • Banjir • Longsor • Gunung Berapi</span>
        </div>
        {/* FD */}
        <div className="bg-gray-800 border border-gray-700 shadow rounded-lg p-4 flex flex-col items-center">
          <h3 className="text-lg font-bold text-gray-200 mb-2">Fasilitas Pendidikan</h3>
          <div className="h-32 w-full bg-gray-700 rounded mb-3 flex items-center justify-center">
            <Bar
              data={{
                labels: hazards.map(h => h.label),
                datasets: buildGroupedDatasets(data, 'fd')
              }}
              options={chartOptions}
            />
          </div>
          <span className="text-center text-gray-400">Gempa Bumi • Banjir • Longsor • Gunung Berapi</span>
        </div>
      </div>
      {/* Pilihan Provinsi (jika ingin tetap ada, bisa diubah stylingnya juga) */}
      <div className="max-w-7xl mx-auto mt-8 flex items-center gap-3">
        <select
          className="flex-1 min-w-[200px] p-2 border border-gray-700 rounded-lg bg-gray-700 text-gray-200 text-sm"
          onChange={e => load(e.target.value)}
          defaultValue=""
        >
          <option key="default" value="" disabled>Pilih Provinsi</option>
          {provs.map((p, index) => (
            <option key={`prov-${index}-${p}`} value={p}>{p}</option>
          ))}
        </select>
      </div>
    </section>
  )
}
