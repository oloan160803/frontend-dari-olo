// components/Header.js
export default function Header() {
  return (
    <header className="bg-gray-800 text-white">
      <div className="max-w-screen-2xl mx-auto flex items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <div>
            <h1 className="text-2xl font-bold font-[space grotesk]">CardinAAL</h1>
            <p className="text-gray-400 text-sm font-[space grotesk]">Calculation for Direct and Average Annual Loss</p>
          </div>
        </div>
        <nav className="flex space-x-4">
          <button
            onClick={() => router.push('/pages/index.js')}
            className="px-4 py-2 text-gray-200 hover:bg-gray-500 rounded transition"
          >
            Home
          </button>
          <button
            onClick={() => router.push('/')}
            className="px-4 py-2 text-gray-200 hover:bg-gray-500 rounded transition"
          >
            Calculation
          </button>
          <button
            onClick={() => router.push('/data')}
            className="px-4 py-2 text-gray-200 hover:bg-gray-500 rounded transition"
          >
            Data
          </button>
        </nav>
      </div>
    </header>
  );
}